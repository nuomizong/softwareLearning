Solarized - OS X Terminal.App Settings
======================================

You will need to have existing xterm-256color terminfo files to run this 
successfully.
